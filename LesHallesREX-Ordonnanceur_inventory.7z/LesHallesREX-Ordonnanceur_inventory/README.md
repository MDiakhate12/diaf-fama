# Présentation

Ce projet git permet de stocker les informations nécessaires aux déploiements :
- pod web airflow : permettant l'accès à l'interface web de airflow
- pod scheduler airflow : permettant d'instancier le scheduler de airflow
- configmap-env : stockant les variables airflow et variable d'environnement airflow
- configmap-script : créant des *fichiers sh* de script pour le déploiement airflow
- role-binding : gérant les droits du airflow
- service : créant les services pour airflow
- secret : créant les secrets pour airflow

# Mise en place nouveau déploiement (changement environnement)

## Construction de l'architecture

1. Créer un nouveau dossier à partir d'un autre environnement hors dev (e.g: *dev04*). L'architecture de ce dossier sera :
- Un dossier <nom de l'environnement>
    - Un dossier **group_vars** : contient les variables globales à passer au helm chart
        - Un dossier **all** : contient les variables globales
            - Un fichier *vars.yml* : contient les variables nécessaires aux jobs jenkins
            - Un fichier *vault.yml* : contient les variables sensibles encryptées
        - Un dossier **configmap** : stocke les variables du configmap et secret à passer au helm chart
            - Un fichier *vars.yml* : contient les variables pour le déploiement du configmap
        - Un dossier **values** : stock les variables générales à passer au helm chart
            - Un fichier *vars.yml* : contient les variables pour le déploiement des pods airflow
            - Un fichier *vault.yml* : contient les variables sensibles encryptées
    - Un dossier **host_vars** : contient les variables spécifiques à l'host à passer au helm chart
        - Un dossier *airflow* : contient les informations de l'image airflow et spark utilisées par les traitements
            - Un fichier **vars.yml** : contient les variables de spécification de l'image airflow et spark
    - *hosts* : contient les inventaires ansible au format yaml
2. Modifier le nom du dossier pour le nom de l'environnement

## Modifications fichier hosts

Les informations présentes dans ce fichier **ne sont pas à modifier**. *Ces valeurs seront modifiées lors d'un changement/évolution de l'architecture Ansible du projet.*

## Modifications du fichier **host_vars/airflow/vars.yml**

Les informations présentes dans ce fichier sont à modifier à chaque release des codes et images applicatives.
voici les informations à changer :

```yaml
## Information à modifier à chaque nouvelle livraison applicative - tag de l'image spark applicative
spark_image_tag: "{{ spark_jars_version }}"
## Information à modifier à chaque nouvelle livraison applicative - version du jars applicatif
spark_jars_version: <version>
```

## Modification des variables globales

### Modification des fichiers group_vars/all

#### Modification du fichier vars.yml

Voici les informations applicatives à modifier :
```yaml
## Information à modifier en changeant de cluster kubernetes
aks:
  server_name: <server name>
  server_url: <url du cluster kubernetes>

[...]
## Information à modifier si changement de la dtr de l'image
registry: <adresse de la dtr>

[...]

## Information à modifier à chaque livraison des helmchart projet lhr présent sous "gitlab-repo-mob.apps.eul.sncf.fr/transilien/groupebigdata-transilien/03168/LesHallesREX-v2/leshallesrex_helmchart.git"
git_chart_version: <tag de la dernière version release>

[...]
```

#### Modification du fichier vault.yml

1. Aller sur le [site SNCF de lecture de fichiers vault](https://vaultonline.apps.eul.sncf.fr/)
2. Récupérer les crédentials présents dans le Keepass Socle
  a. <u>Si vous êtes partis des fichiers de l'environnement **dev04**</u>, le mot de passe de décryptage est présent sous **Deployment/VALID/lhr-dev04-airflow-vault**
3. Copier/coller le mot de passe dans le champ "Clé de chiffrement"
4. Récupérer le contenu du fichier vault
5. Copier/coller le contenu dans la partie gauche
6. Cliquer sur "Chiffrer/Déchiffrer"
7. Modifier les champs suivants

```yaml
## Information à changer en changeant de namespace et/ou de cluster kubernetes
## Information à récupérer dans le Keepass Socle, partie Cluster AKS/Env/File attachments/Cluster_Name.zip
vault_aks_private:
  certificate_authority_data: <certificat lié au namespace et serveur>
  client_key_data: <clé cliente lié au namespace et serveur>
  token: <token de connexion au namespace et serveur>

## Information non obligatoire à changer, à modifier si utilisateur avec des droits différents pour le nouvel environnement
vault_git_chart_user: <nom d'un user master sur le git helm>
vault_git_chart_password: <mot de passe ou token du user précédent>
```

8. Récupérer le texte modifié et copier/coller le sur la partie de gauche
9. Cliquer sur "Chiffrer/Déchiffrer" avec la clé précédemment rentrée
10. Récupérer le vault généré
11. Copier/Coller le dans le fichier vault.yaml

### Modification des fichiers group_vars/configmap

#### Modification du fichier vars.yml

**Pas de modification à prévoir** car pas d'utilisation de variable dans ce fichier.

### Modification des fichiers group_vars/values

#### Modification du fichier vars.yml

Seules les variables suivantes sont à modifier :
```yaml
[...]
image:
  repository: "{{ repository }}/{{ docker_image_name }}"
  tag: "{{ version }}"
  pullPolicy: Always
  ## Information à changer en changeant de cluster kubernetes si le secret de connexion à la dtr n'est pas de la forme "regcred-gbdtn-env-secret"
  pullSecret: <nom du secret de connexion à la dtr>

[...]
config:
[...]
  ## Information à changer en changeant de cluster kubernetes si le service-account-name n'est pas de la forme "sa-sbt-env[n°]"
  AIRFLOW__KUBERNETES__WORKER_SERVICE_ACCOUNT_NAME: <service account du namespace>

  ## Information à changer en changeant de cluster kubernetes si le deploiement du configmap spark n'a plus un nom de la forme leshallesrex-indicateurs-env-configmap"
  AIRFLOW_VAR_SPARKCONF: <nom configmap spark deployé>
  AIRFLOW__KUBERNETES_ENVIRONMENT_VARIABLES__AIRFLOW_VAR_SPARKCONF: <nom configmap spark deployé>

  ## Information à changer en changeant d'environnement pour cibler le bon conteneur blob utilisé par les traitements
  AIRFLOW_VAR_WASBADRESS: <wasbs://<conteneur>@<serviceaccount>.blob.core.windows.net>
  AIRFLOW__KUBERNETES_ENVIRONMENT_VARIABLES__AIRFLOW_VAR_WASBADRESS: <wasbs://<conteneur>@<serviceaccount>.blob.core.windows.net

  ## Information à changer en changeant d'environnement pour cibler le bon azure datalakestore utilisé par les traitements
  AIRFLOW_VAR_ADLADRESS: <adl://<datalakeName>.azuredatalakestore.net>
  AIRFLOW__KUBERNETES_ENVIRONMENT_VARIABLES__AIRFLOW_VAR_ADLADRESS: <adl://<datalakeName>.azuredatalakestore.net>

  ## Information à changer en changeant de cluster kubernetes si le service-account-name n'est pas de la forme "sa-sbt-env[n°]"
  AIRFLOW_VAR_SERVICE_ACCOUNT_NAME: <service account du namespace>
  AIRFLOW__KUBERNETES_ENVIRONMENT_VARIABLES__AIRFLOW_VAR_SERVICE_ACCOUNT_NAME: <service account du namespace>

  ## Information à changer en changeant de cluster kubernetes si le namespace n'est pas de la forme "sbt-env[n°]"
  AIRFLOW_VAR_NAMESPACE: <namespace>
  AIRFLOW__KUBERNETES_ENVIRONMENT_VARIABLES__AIRFLOW_VAR_NAMESPACE: <namespace>

  ## Information à changer en changeant de cluster kubernetes si le secret de connexion à la dtr n'est pas de la forme "regcred-gbdtn-env-secret"
  AIRFLOW_VAR_REGCRED: <nom du secret de connexion à la dtr>
  AIRFLOW__KUBERNETES_ENVIRONMENT_VARIABLES__AIRFLOW_VAR_REGCRED: <nom du secret de connexion à la dtr>

[...]

  kubernetesExecutor:
    repository: "{{ repository }}/{{ docker_image_name }}"
    tag: "{{ version }}"
    pullPolicy: Always
    ## Information à changer en changeant de cluster kubernetes si le secret de connexion à la dtr n'est pas de la forme "regcred-gbdtn-env-secret"
    pullSecret: <nom du secret de connexion à la dtr>
    ## Information à changer en changeant de cluster kubernetes si le namespace n'est pas de la forme "sbt-env[n°]"
    namespace: <namespace>

    ## Information à changer si les connexions au datadog du nouvel environnement sont différentes
    ## See Denis ERCHOFF
    statsd:
      enabled: true
      host: <ip host adress>
      port: <port>
      prefix: <prefix>

    datadogAgent:
      site: <site adress>
      traceAgentUrl: <site url>
      apiKey: <api key>
      profilingApiUrl: <profiling api url>
      agentHost: <agent ip host adress>
      traceAgentPort: <agent port>

[...]
```

Les variables suivantes sont **à supprimer** *(dans les environnements autres que Dev et Valid)*:
```yaml
## See https://airflow.apache.org/docs/1.10.10/configurations-ref.html#remote-logging
AIRFLOW__CORE__REMOTE_LOGGING: "true"
AIRFLOW__KUBERNETES_ENVIRONMENT_VARIABLES__AIRFLOW__CORE__REMOTE_LOGGING: "true"
## See https://airflow.apache.org/docs/1.10.10/configurations-ref.html#remote-log-conn-id
AIRFLOW__CORE__REMOTE_LOG_CONN_ID: "wasb_default"
AIRFLOW__KUBERNETES_ENVIRONMENT_VARIABLES__AIRFLOW__CORE__REMOTE_LOG_CONN_ID: "wasb_default"
## See https://airflow.apache.org/docs/1.10.10/configurations-ref.html#remote-base-log-folder
AIRFLOW__CORE__REMOTE_BASE_LOG_FOLDER: "wasb-airflow-logs/{{ environnement }}"
AIRFLOW__KUBERNETES_ENVIRONMENT_VARIABLES__AIRFLOW__CORE__REMOTE_BASE_LOG_FOLDER: "wasb-airflow-logs/{{ environnement }}"
```

#### Modification du fichier vault.yml

1. Aller sur le [site SNCF de lecture de fichiers vault](https://vaultonline.apps.eul.sncf.fr/)
2. Récupérer les crédentials présents dans le Keepass Socle
  a. <u>Si vous êtes partis des fichiers de l'environnement **dev04**</u>, le mot de passe de décryptage est présent sous **Deployment/VALID/lhr-dev04-spark-vault**
3. Copier/coller le mot de passe dans le champ "Clé de chiffrement"
4. Récupérer le contenu du fichier vault
5. Copier/coller le contenu dans la partie gauche
6. Cliquer sur "Chiffrer/Déchiffrer"
7. Modifier les champs suivants
```yaml
## Information à changer par environnement
## Encryption key for airflow to encrypt data
vault_fernet_key: <fernet_key>
## Information à changer si l'on change d'environnement
## adresse de la base postgresql utilisée par airflow
vault_backend_server: <<nom de ressource>.postgres.database.azure.com>
## Information à changer si l'on change de base
vault_backend_username: <nom du user postgresql pour le schéma donné>
## Information à changer si l'on change de base
vault_backend_password: <mot de passe du user postgresql pour le schéma donné>
## Information à changer si l'on change de base
vault_backend_database: <nom du schéma>
## Information à changer si l'on change d'environnement postgres de dataviz
## adresse de la base postgresql de dataviz utilisée par airflow
vault_dataviz_server: <<nom de ressource>.postgres.database.azure.com>
## Information à changer si l'on change de username
vault_dataviz_username: <nom du user postgresql pour le schéma de dataviz donné>
## Information à changer si l'on change de mot de passe
vault_dataviz_password: <mot de passe du user postgresql pour le schéma de dataviz donné>
## Information à changer si l'on change de base
vault_dataviz_database: <nom du schéma de dataviz>
## Information à changer si l'on change de port 
vault_dataviz_port: <port postgres pour le schéma de dataviz donné>
```
8. Récupérer le texte modifié et copier/coller le sur la partie de gauche
9. Cliquer sur "Chiffrer/Déchiffrer" avec la clé précédemment rentrée
10. Récupérer le vault généré
11. Copier/Coller le dans le fichier vault.yml
