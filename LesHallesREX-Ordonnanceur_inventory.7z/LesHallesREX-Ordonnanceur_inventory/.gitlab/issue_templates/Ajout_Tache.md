# Ajout de Paramètres de Task Airflow

## **Uniquement pour l'environnement dev01**

* Dans votre fichier ``inventories/dev01/host_vars/${user}/vars.yml`` personnel, pointer vers votre développement spark:

````yaml
host_apps:
  ${global_use_case}:
    spark:
      docker_tag: version-${votre_branche_spark}-SNAPSHOT
      version: version-${votre_branche_spark}-SNAPSHOT
      config_map: leshallesrex-indicateurs-${user}-configmap
  [...]
````

## **Uniquement pour les environnements ass01, ass02, dev01, et dev02**

* Créer ensuite le fichier ````inventories/${env}/group_vars/values/${use_case}.yml```` correspondant à votre task, ou implémenter votre task à la suite d'autres task dans un use_case pré-existant:

````yaml
dag_name_${use_case}:
  ${use_case}_run:
    name: "${use_case}-RUN"

spark_arguments_${use_case}:
  "${TASK}:
    dag:
      name: "{{ dag_name_${use_case}.${use_case}_run.name }}"
    task:
      name: "${USE_CASE}"
    configmap:
      name: "{{ apps.leshallesrex.spark.config_map }}"
    service:
      name: "${task}-svc"
      app_name: "lhr"
    arguments:
      class: "${class.path}"
      app_name: "${task}"
      image_name: "{{ spark_leshallesrex_repository }}/{{ apps.leshallesrex.spark.docker_image }}:{{ apps.leshallesrex.spark.docker_tag }}"
      jar_name: "{{ apps.leshallesrex.spark.artifact }}-{{ apps.leshallesrex.spark.version }}.jar"
      service_host: "leshallesrex-indicateurs-${task}-svc-service.{{ namespace }}.svc"
      driver:
        request_cpu: "1000m"
        limit_cpu: "2000m"
        request_memory: "2048Mi"
        limit_memory: "4096Mi"
        memory: "2G"
        extraJavaOptions: "{{ defaultOptions.driverDefaultOptions }} -D${extras_java_options} [...]"
      executor:
        request_cpu: "2000m"
        limit_cpu: "3000m"
        memory: "4G"
        cores: "3"
        instances: "2"
        extraJavaOptions: "{{ defaultOptions.executorDefaultOptions }} "
        datadog_tag: "{\"app\": \"{{ application }}\", \"usecase\": \"${task}\", \"env\":\"{{ namespace }}\", \"version\":\"{{ version }}\", \"spark-role\":\"executor\" }"
````

* Ajouter les variables nécessaires à votre développement dans le fichiers ````inventories/${env}/group_vars/values/db_values.yml````. L'emplacement de vos variables dans la structure du ````db_values.yml```` doit correspondre au path de vos extra_java_options

````yaml
default_path:
  blob: "wasbs://{{ lhr.blobStorage.container.name }}@{{ lhr.storageAccount.blobService.url }}"
  adls: "{{ lhr.DataLakeStorage.ADL_URI }}"
  database:
    [...]
  ${db_1}:
    ${your_key1} : "${value1}"
  ${db_2}:
    ${your_key2} : "${value2}"
````

* Dans le fichier ````inventories/${env}/group_vars/values/vars.yml````, chercher les clefs ````AIRFLOW_VAR_SPARK_ARG_*```` et ````AIRFLOW_VAR_DAG_NAME```` et ajouter votre use_case si besoin:

````yaml
      AIRFLOW_VAR_SPARK_ARG_${USE_CASE}: "{{ spark_arguments_${USE_CASE_1} | [...] | combine(spark_arguments_${VOTRE_USE_CASE}) | to_json | b64encode }}"
      AIRFLOW__KUBERNETES_ENVIRONMENT_VARIABLES__AIRFLOW_VAR_SPARK_ARG_${USE_CASE}: "{{ spark_arguments_${USE_CASE_1} | [...] | combine(spark_arguments_${VOTRE_USE_CASE}) | to_json | b64encode }}"

            ## Defines the json variable to use for dag name of airflow dag
      AIRFLOW_VAR_DAG_NAME: "{{ dag_name_${use_case_1} | [...] | combine(dag_name_${your_use_case}) | to_json | b64encode }}"
      AIRFLOW__KUBERNETES_ENVIRONMENT_VARIABLES__AIRFLOW_VAR_DAG_NAME: "{{ dag_name_${use_case_1} | [...] | combine(dag_name_${your_use_case}) | to_json | b64encode }}"
````