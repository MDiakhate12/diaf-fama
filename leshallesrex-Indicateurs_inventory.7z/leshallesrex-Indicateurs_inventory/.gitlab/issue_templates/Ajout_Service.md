# Ajout de Service(s)

* **Uniquement pour les environnements ass01, ass02, dev01, et dev02**, ouvrir les fichiers ``ìnventories/${env}/hosts``, puis ajouter votre service ```${your_usecase}``` en le suffixant par ```-svc``` comme il suit:

````yaml
  all:
    vars:
      ansible_connection: local
    children:
      values:
        hosts:
          spark:
          [..]
          usecasen-1-svc:
          ${your_usecase}-svc:
          usecasen+1-svc:
          [..]
      configmap:
        hosts:
          spark:
          [..]
          usecasen-1-svc:
          ${your_usecase}-svc:
          usecasen+1-svc:
          [..]
      service:
        children:
          no_service:
            vars:
              ## Enable configmap
              ConfigmapEnabled: true
              ## Disable service deployment
              serviceEnabled: false
              DeployementEnabled: false
            hosts:
              [..]
        hosts:
          spark:
          [..]
          usecasen-1-svc:
          ${your_usecase}-svc:
          usecasen+1-svc:
          [..]
````