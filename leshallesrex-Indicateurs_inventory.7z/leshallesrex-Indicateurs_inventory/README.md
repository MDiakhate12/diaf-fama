# Présentation

Ce projet git permet de stocker les informations nécessaires aux déploiements :
- configMap : créant un fichier **spark-defaults.conf** stockant les valeurs utilisées que Spark utilisera par défaut
- pod spark-history : permettant de mettre à disposition une spark-history pour la supervisions de traitements

# Mise en place nouveau déploiement (changement environnement)

## Construction de l'architecture

1. Créer un nouveau dossier à partir d'un autre environnement hors dev (e.g: *dev04*). L'architecture de ce dossier sera :
- Un dossier <nom de l'environnement>
    - Un dossier **group_vars** : contient les variables globales à passer au helm chart
        - Un dossier **all** : contient les variables globales
            - Un fichier *vars.yml* : contient les variables nécessaires aux jobs jenkins
            - Un fichier *vault.yml* : contient les variables sensibles encryptées
        - Un dossier **configmap** : stocke les variables du configmap et secret à passer au helm chart
            - Un fichier *vars.yml* : contient les variables pour le déploiement du configmap
            - Un fichier *vault.yml* : contient les variables sensibles encryptées
        - Un dossier **values** : stock les variables générales à passer au helm chart
            - Un fichier *vars.yml* : contient les variables pour le déploiement du pods spark-history
    - Un dossier **host_vars** : contient les variables spécifiques à l'host à passer au helm chart
        - Un dossier *spark* : contient les informations de l'image spark à utiliser pour la spark history
            - Un fichier **vars.yml** : contient les variables de spécification de l'image spark
    - *hosts* : contient les inventaires ansible au format yaml
2. Modifier le nom du dossier pour le nom de l'environnement

## Modifications fichier hosts

Les informations présentes dans ce fichier **ne sont pas à modifier**. *Ces valeurs seront modifiées lors d'un changement/évolution de l'architecture Ansible du projet.*

## Modifications du fichier **host_vars/spark/vars.yml**

Les informations présentes dans ce fichier **ne sont pas à modifier**. *Ces valeurs seront modifiées lors du changement de la version de l'image spark common lhr servant de base pour le pod spark-history.*

Si besoin voici un récapitulatif des informations présentes :

```yaml
## Information à modifier si changement du nom de l'image de base spark socle
docker_image: lhr-common-spark
## Information à modifier si changement du tag de l'image de base spark socle
version: "0.0.0.5"
```

## Modification des variables globales

### Modification des fichiers group_vars/all

#### Modification du fichier vars.yml

Voici les informations applicatives à modifier :
```yaml
## Information à modifier en changeant de cluster kubernetes
aks:
  server_name: <server name>
  server_url: <url du cluster kubernetes>

[...]
## Information à modifier si changement de la dtr de l'image
registry: <adresse de la dtr>

[...]

## Information à modifier à chaque livraison des helmchart projet lhr présent sous "gitlab-repo-mob.apps.eul.sncf.fr/transilien/groupebigdata-transilien/03168/LesHallesREX-v2/leshallesrex-scala_helmchart.git"
git_chart_version: <tag de la dernière version release>

[...]
```

#### Modification du fichier vault.yml

1. Aller sur le [site SNCF de lecture de fichiers vault](https://vaultonline.apps.eul.sncf.fr/)
2. Récupérer les crédentials présents dans le Keepass Socle
  a. <u>Si vous êtes partis des fichiers de l'environnement **dev04**</u>, le mot de passe de décryptage est présent sous **Deployment/VALID/lhr-dev04-spark-vault** 
3. Copier/coller le mot de passe dans le champ "Clé de chiffrement"
4. Récupérer le contenu du fichier vault
5. Copier/coller le contenu dans la partie gauche
6. Cliquer sur "Chiffrer/Déchiffrer"
7. Modifier les champs suivants

```yaml
## Information à changer en changeant de namespace et/ou de cluster kubernetes
## Information à récupérer dans le Keepass Socle, partie Cluster AKS/Env/File attachments/Cluster_Name.zip
vault_aks_private:
  certificate_authority_data: <certificat lié au namespace et serveur>
  client_key_data: <clé cliente lié au namespace et serveur>
  token: <token de connexion au namespace et serveur>

## Information non obligatoire à changer, à modifier si l'utilisateur avec des droits différents pour le nouvel environnement
vault_git_chart_user: <nom d'un user master sur le git helm>
vault_git_chart_password: <mot de passe ou token du user précédent>
```

8. Récupérer le texte modifié et copier/coller le sur la partie de gauche
9. Cliquer sur "Chiffrer/Déchiffrer" avec la clé précédemment rentrée
10. Récupérer le vault généré
11. Copier/Coller le dans le fichier vault.yaml

### Modification des fichiers group_vars/configmap

#### Modification du fichier vars.yml

Voici les informations applicatives à modifier dans la partie **data** :
```yaml
## Information à changer en changeant de cluster kubernetes
master: <k8s://master kubernetes-{{ vault_k8s_url_suffix }}:443">
## Information à changer en changeant de cluster kubernetes si le namespace n'est pas de la forme "sbt-env[n°]"
namespace: <namespace>
## Information à changer en changeant de cluster kubernetes si le service-account-name n'est pas de la forme "sa-sbt-env[n°]"
accountname: <service account du namespace>
## Information à changer en changeant de cluster kubernetes si le secret de connexion à la dtr n'est pas de la forme "regcred-gbdtn-env-secret"
regcred: <nom du secret de connexion à la dtr>
## Information à changer en changeant d'environnement sous forme LHR[Env]
driverlabels: LHRDev
## Information à changer en changeant d'environnement sous forme LHR[Env]
executorlabels: LHRDev
## Information à changer en changeant d'environnement pour cibler le bon conteneur blob
## Dossier de stockage par défaut des données spark
warehousedir: <wasbs://<conteneur>@<serviceaccount>.blob.core.windows.net/<sous chemin>>

[...]

## Information à changer en changeant d'environnement pour cibler le bon conteneur blob
## Dossier stockant les logs spark utilisés par la spark-history
eventlogdir: <wasbs://<conteneur>@<serviceaccount>.blob.core.windows.net/<sous chemin log>>
## Information à changer en changeant d'environnement pour cibler le bon service account correspondant au conteneur blob utiliser
storageaccountname: <service account blob>

[...]

## Information à changer en changeant d'environnement pour cibler le bon conteneur blob
## Dossier utiliser comme fileSystem par défaut
defaultfs: <wasbs://<conteneur>@<serviceaccount>.blob.core.windows.net/<sous chemin>>

[...]

## Information Datadog à changer en changeant d'environnement
## nom du cluster
clustername: PZKBSBTT01-dev
## Information Datadog à changer en changeant d'environnement
## environnement
datadoglabelenv: dev
## Information Datadog à changer en changeant d'environnement sous forme LHR[Env]
datadoglabelservice: LHRDev
## Information Datadog à changer en changeant d'environnement
## version du livrable/image utilisée
datadoglaberversion: 1.33.8
```

#### Modification du fichier vault.yml

1. Aller sur le [site SNCF de lecture de fichiers vault](https://vaultonline.apps.eul.sncf.fr/)
2. Récupérer les crédentials présents dans le Keepass Socle
  a. <u>Si vous êtes partis des fichiers de l'environnement **dev04**</u>, le mot de passe de décryptage est présent sous **Deployment/VALID/lhr-dev04-spark-vault** 
3. Copier/coller le mot de passe dans le champ "Clé de chiffrement"
4. Récupérer le contenu du fichier vault
5. Copier/coller le contenu dans la partie gauche
6. Cliquer sur "Chiffrer/Déchiffrer"
7. Modifier les champs suivants
```yaml
## Information à changer en changeant de cluster kubernetes
vault_k8s_url_suffix: <suffix adresse kubernetes>
## Information à changer en changeant de storage account blob
vault_storage_account_key: <storage account key pour blob>
## Information à changer en changeant de souscription azure
vault_azure_subcription_id: <id souscription azure>
## Information à changer en changeant de service principal datalakestore
vault_azure_service_principal_client_id: <client id>
## Information à changer en changeant de service principal datalakestore
vault_azure_service_principal_secret: <secret>
## Information à changer en changeant de base postgresql HiveMetaStore
vault_postgres_url: jdbc:postgresql://<nom de ressource>.postgres.database.azure.com:<port>/<schéma>
## Information à changer en changeant de base postgresql HiveMetaStore
vault_postgres_user: <nom du user postgresql pour le schéma donné>
## Information à changer en changeant de base postgresql HiveMetaStore
vault_postgres_mdp: <mot de passe du user postgresql pour le schéma donné>
```
8. Récupérer le texte modifié et copier/coller le sur la partie de gauche
9. Cliquer sur "Chiffrer/Déchiffrer" avec la clé précédemment rentrée
10. Récupérer le vault généré
11. Copier/Coller le dans le fichier vault.yml

### Modification des fichiers group_vars/values

#### Modification du fichier vars.yml

Seules les variables suivantes sont à modifier :
```yaml
[...]

  spec:
    containersName: spark-history-lhr
    ## Information à changer en changeant de cluster kubernetes si le secret de connexion à la dtr n'est pas de la forme "regcred-gbdtn-env-secret"
    PullSecrets: regcred-gbdtn-{{ environnement }}-secret

[...]
```